import React, { useState, useEffect, useRef } from 'react';
import HUD from './components/HUD';
import StartScreen from './components/StartScreen';
import About from './components/About';
import LandingPages from './components/LandingPages';
import SocialMedia from './components/SocialMedia';
import VideoEditing from './components/VideoEditing';
import Projects from './components/Projects';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ParticleSystem from './components/ParticleSystem';

function App() {
  const [currentSection, setCurrentSection] = useState('start');
  const [xp, setXp] = useState(0);
  const [scrollY, setScrollY] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const appRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
      
      // Detect current section based on scroll position
      const sections = ['start', 'about', 'landing-pages', 'social-media', 'video-editing', 'projects', 'contact'];
      const sectionElements = sections.map(id => document.getElementById(id));
      
      let current = 'start';
      sectionElements.forEach((element, index) => {
        if (element && element.offsetTop <= window.scrollY + 200) {
          current = sections[index];
        }
      });
      
      setCurrentSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const addXP = (amount: number) => {
    setXp(prev => prev + amount);
  };

  const playSound = (type: 'click' | 'hover' | 'success') => {
    if (isMuted) return;
    // Sound effects would be implemented here
    console.log(`Sound: ${type}`);
  };

  return (
    <div 
      ref={appRef}
      className="min-h-screen bg-gray-900 text-white crt-effect relative overflow-x-hidden"
      style={{ background: 'linear-gradient(135deg, #0F0F1A 0%, #1a1a2e 50%, #16213e 100%)' }}
    >
      <ParticleSystem />
      
      <HUD 
        currentSection={currentSection}
        xp={xp}
        isMuted={isMuted}
        onToggleMute={() => setIsMuted(!isMuted)}
      />

      <main className="pt-16">
        <section id="start">
          <StartScreen 
            onAddXP={addXP}
            onPlaySound={playSound}
          />
        </section>

        <section id="about">
          <About 
            onAddXP={addXP}
            onPlaySound={playSound}
          />
        </section>

        <section id="landing-pages">
          <LandingPages 
            onAddXP={addXP}
            onPlaySound={playSound}
          />
        </section>

        <section id="social-media">
          <SocialMedia 
            onAddXP={addXP}
            onPlaySound={playSound}
          />
        </section>

        <section id="video-editing">
          <VideoEditing 
            onAddXP={addXP}
            onPlaySound={playSound}
          />
        </section>

        <section id="projects">
          <Projects 
            onAddXP={addXP}
            onPlaySound={playSound}
          />
        </section>

        <section id="contact">
          <Contact 
            onAddXP={addXP}
            onPlaySound={playSound}
          />
        </section>
      </main>

      <Footer />
    </div>
  );
}

export default App;