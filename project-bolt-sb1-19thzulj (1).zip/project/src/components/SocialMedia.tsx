import React, { useState } from 'react';
import { TrendingUp, Calendar, Zap, BarChart3, Instagram, ChevronLeft, ChevronRight } from 'lucide-react';

interface SocialMediaProps {
  onAddXP: (amount: number) => void;
  onPlaySound: (type: 'click' | 'hover' | 'success') => void;
}

const SocialMedia: React.FC<SocialMediaProps> = ({ onAddXP, onPlaySound }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const skills = [
    {
      icon: Calendar,
      title: 'Calendário Editorial',
      description: 'Planejamento estratégico de conteúdo'
    },
    {
      icon: Zap,
      title: 'Hooks de 3s',
      description: 'Primeiros segundos que prendem atenção'
    },
    {
      icon: Instagram,
      title: 'Formatos Reels/Shorts',
      description: 'Conteúdo otimizado para cada plataforma'
    },
    {
      icon: BarChart3,
      title: 'Métricas Básicas',
      description: 'Análise de engajamento e performance'
    }
  ];

  const mockPosts = [
    {
      type: 'carousel',
      title: 'Landing Pages que Convertem',
      description: '5 elementos essenciais para uma LP de alta conversão',
      engagement: '89% mais engajamento'
    },
    {
      type: 'video',
      title: 'Análise de LP Real',
      description: 'Breakdown completo de uma landing page vencedora',
      engagement: '156 comentários'
    },
    {
      type: 'story',
      title: 'Dica Rápida: CTAs',
      description: 'Como escrever calls-to-action irresistíveis',
      engagement: '78% de completion rate'
    },
    {
      type: 'reel',
      title: 'Erro Comum em LPs',
      description: 'O que 90% das landing pages fazem errado',
      engagement: '234 shares'
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % mockPosts.length);
    onPlaySound('click');
    onAddXP(5);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + mockPosts.length) % mockPosts.length);
    onPlaySound('click');
    onAddXP(5);
  };

  return (
    <div className="min-h-screen py-20 px-4 relative">
      {/* Section Header */}
      <div className="max-w-6xl mx-auto text-center mb-16">
        <h2 className="pixel-font text-3xl md:text-4xl text-magenta-400 neon-glow mb-4"
            style={{ color: '#FF4DDE' }}>
          SIDE QUEST: SOCIAL MEDIA
        </h2>
        <p className="pixel-font-mono text-lg text-white">
          Crio posts e vídeos otimizados para engajamento e tendência,
        </p>
        <p className="pixel-font-mono text-lg text-gray-300">
          alinhando estética à performance
        </p>
        <div className="w-32 h-1 bg-gradient-to-r from-pink-400 to-purple-400 mx-auto mt-4"></div>
      </div>

      <div className="max-w-6xl mx-auto space-y-16">
        {/* Skills Chips */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {skills.map((skill, index) => (
            <div
              key={index}
              onClick={() => onAddXP(5)}
              onMouseEnter={() => onPlaySound('hover')}
              className="pixel-card p-4 hover-lift cursor-pointer group"
            >
              <div className="text-center">
                <skill.icon className="w-8 h-8 mx-auto mb-3 text-pink-400 group-hover:text-purple-400 transition-colors" />
                <h3 className="pixel-font text-xs text-white mb-2">
                  {skill.title}
                </h3>
                <p className="pixel-font-mono text-xs text-gray-400 leading-relaxed">
                  {skill.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Mock Posts Carousel */}
        <div className="pixel-card p-8">
          <h3 className="pixel-font text-xl text-pink-400 neon-glow mb-8 text-center">
            PORTFÓLIO DE CONTEÚDO
          </h3>

          <div className="relative">
            {/* Carousel Container */}
            <div className="bg-gradient-to-br from-pink-900/20 to-purple-900/20 p-6 rounded-lg border border-pink-400/30">
              <div className="flex items-center justify-between mb-6">
                <button
                  onClick={prevSlide}
                  onMouseEnter={() => onPlaySound('hover')}
                  className="p-2 text-pink-400 hover:text-white transition-colors hover-lift"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>

                {/* Current Post Display */}
                <div className="flex-1 mx-8">
                  <div className="bg-black/50 p-6 border border-pink-400/50 relative">
                    {/* Post Type Indicator */}
                    <div className="absolute top-2 right-2">
                      <span className="pixel-font-mono text-xs text-pink-400 bg-black px-2 py-1 border border-pink-400">
                        {mockPosts[currentSlide].type.toUpperCase()}
                      </span>
                    </div>

                    {/* Mock Content Preview */}
                    <div className="aspect-square bg-gradient-to-br from-pink-500/20 to-purple-500/20 mb-4 flex items-center justify-center">
                      <TrendingUp className="w-16 h-16 text-pink-400 opacity-50" />
                    </div>

                    <h4 className="pixel-font text-sm text-white mb-2">
                      {mockPosts[currentSlide].title}
                    </h4>

                    <p className="pixel-font-mono text-xs text-gray-300 mb-3">
                      {mockPosts[currentSlide].description}
                    </p>

                    <div className="flex items-center justify-between">
                      <span className="pixel-font-mono text-xs text-pink-400">
                        📊 {mockPosts[currentSlide].engagement}
                      </span>
                      
                      <div className="text-xs text-gray-400">
                        {currentSlide + 1} / {mockPosts.length}
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={nextSlide}
                  onMouseEnter={() => onPlaySound('hover')}
                  className="p-2 text-pink-400 hover:text-white transition-colors hover-lift"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </div>

              {/* Slide Indicators */}
              <div className="flex justify-center space-x-2">
                {mockPosts.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setCurrentSlide(index);
                      onPlaySound('click');
                    }}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      currentSlide === index ? 'bg-pink-400' : 'bg-gray-600'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Demo Notice */}
            <div className="text-center mt-4">
              <span className="pixel-font-mono text-xs text-gray-400">
                * Exemplos demonstrativos - Portfólio real em desenvolvimento
              </span>
            </div>
          </div>
        </div>

        {/* Strategy Breakdown */}
        <div className="pixel-card p-8">
          <h3 className="pixel-font text-lg text-pink-400 neon-glow mb-6 text-center">
            ESTRATÉGIA DE CONTEÚDO
          </h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center p-4 border border-pink-400/30 bg-pink-900/10">
              <div className="text-2xl mb-3">🎯</div>
              <h4 className="pixel-font text-sm text-white mb-2">FOCO</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Landing Pages e conversão como tema central
              </p>
            </div>
            
            <div className="text-center p-4 border border-pink-400/30 bg-pink-900/10">
              <div className="text-2xl mb-3">📈</div>
              <h4 className="pixel-font text-sm text-white mb-2">PERFORMANCE</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Conteúdo baseado em dados e tendências
              </p>
            </div>
            
            <div className="text-center p-4 border border-pink-400/30 bg-pink-900/10">
              <div className="text-2xl mb-3">🎨</div>
              <h4 className="pixel-font text-sm text-white mb-2">CRIATIVIDADE</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Visual atrativo que se destaca no feed
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Background Decoration */}
      <div className="absolute top-20 right-10 w-4 h-4 bg-pink-400 animate-pulse opacity-20"></div>
      <div className="absolute bottom-20 left-10 w-3 h-3 bg-purple-400 animate-ping opacity-20"></div>
    </div>
  );
};

export default SocialMedia;