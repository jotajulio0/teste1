import React, { useState } from 'react';
import { Video, Scissors, Zap, Play, Volume2 } from 'lucide-react';

interface VideoEditingProps {
  onAddXP: (amount: number) => void;
  onPlaySound: (type: 'click' | 'hover' | 'success') => void;
}

const VideoEditing: React.FC<VideoEditingProps> = ({ onAddXP, onPlaySound }) => {
  const [activeVideo, setActiveVideo] = useState<number | null>(null);

  const tools = [
    {
      name: 'CapCut',
      level: 90,
      description: 'Mobile editing, quick cuts, trending effects'
    },
    {
      name: 'Premiere Pro',
      level: 75,
      description: 'Professional editing, color correction, audio mixing'
    },
    {
      name: 'After Effects',
      level: 60,
      description: 'Motion graphics, animations, visual effects'
    }
  ];

  const videoProjects = [
    {
      title: 'Landing Page Breakdown',
      type: 'Educational',
      duration: '2:30',
      description: 'Análise detalhada de elementos de conversão',
      platforms: ['Instagram', 'YouTube Shorts'],
      thumbnail: '📊'
    },
    {
      title: 'Processo de Criação',
      type: 'Behind the Scenes',
      duration: '1:45',
      description: 'Como desenvolvo uma LP do zero',
      platforms: ['TikTok', 'Instagram Reels'],
      thumbnail: '⚡'
    },
    {
      title: 'Antes vs Depois',
      type: 'Case Study',
      duration: '3:15',
      description: 'Transformação de LP com baixa conversão',
      platforms: ['LinkedIn', 'YouTube'],
      thumbnail: '🔄'
    },
    {
      title: 'Dicas Rápidas',
      type: 'Tips & Tricks',
      duration: '0:45',
      description: 'CTA que realmente funcionam',
      platforms: ['Stories', 'Shorts'],
      thumbnail: '💡'
    }
  ];

  const handleVideoHover = (index: number) => {
    setActiveVideo(index);
    onPlaySound('hover');
  };

  const handleVideoClick = (index: number) => {
    onPlaySound('click');
    onAddXP(8);
  };

  return (
    <div className="min-h-screen py-20 px-4 relative">
      {/* Section Header */}
      <div className="max-w-6xl mx-auto text-center mb-16">
        <h2 className="pixel-font text-3xl md:text-4xl text-yellow-400 neon-glow mb-4">
          POWER-UP: EDIÇÃO DE VÍDEO
        </h2>
        <p className="pixel-font-mono text-lg text-white">
          Edição e motion para dar ritmo à mensagem,
        </p>
        <p className="pixel-font-mono text-lg text-gray-300">
          do corte ao efeito certo para a plataforma
        </p>
        <div className="w-32 h-1 bg-gradient-to-r from-yellow-400 to-orange-400 mx-auto mt-4"></div>
      </div>

      <div className="max-w-6xl mx-auto space-y-16">
        {/* Tools Proficiency */}
        <div className="pixel-card p-8">
          <h3 className="pixel-font text-xl text-yellow-400 neon-glow mb-8 text-center">
            FERRAMENTAS DOMINADAS
          </h3>
          
          <div className="space-y-6">
            {tools.map((tool, index) => (
              <div
                key={index}
                className="flex items-center space-x-6 p-4 border border-yellow-400/30 hover:border-yellow-400 transition-colors cursor-pointer"
                onMouseEnter={() => onPlaySound('hover')}
                onClick={() => onAddXP(5)}
              >
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-lg flex items-center justify-center">
                    <Video className="w-8 h-8 text-black" />
                  </div>
                </div>
                
                <div className="flex-1">
                  <h4 className="pixel-font text-lg text-white mb-2">{tool.name}</h4>
                  <p className="pixel-font-mono text-sm text-gray-300 mb-3">
                    {tool.description}
                  </p>
                  
                  <div className="flex items-center space-x-3">
                    <span className="pixel-font-mono text-xs text-yellow-400">
                      Proficiência:
                    </span>
                    <div className="flex-1 progress-bar max-w-xs">
                      <div 
                        className="progress-fill bg-gradient-to-r from-yellow-400 to-orange-400" 
                        style={{ width: `${tool.level}%` }}
                      ></div>
                    </div>
                    <span className="pixel-font-mono text-xs text-white">
                      {tool.level}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Video Portfolio */}
        <div className="pixel-card p-8">
          <h3 className="pixel-font text-xl text-yellow-400 neon-glow mb-8 text-center">
            GALERIA DE PROJETOS
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            {videoProjects.map((video, index) => (
              <div
                key={index}
                onMouseEnter={() => handleVideoHover(index)}
                onMouseLeave={() => setActiveVideo(null)}
                onClick={() => handleVideoClick(index)}
                className="pixel-card p-6 cursor-pointer relative group overflow-hidden"
              >
                {/* Video Thumbnail */}
                <div className="aspect-video bg-gradient-to-br from-yellow-900/30 to-orange-900/30 mb-4 flex items-center justify-center relative border border-yellow-400/30">
                  <div className="text-6xl opacity-50">{video.thumbnail}</div>
                  
                  {/* Play Button Overlay */}
                  <div className={`absolute inset-0 bg-black/60 flex items-center justify-center transition-opacity duration-300 ${
                    activeVideo === index ? 'opacity-100' : 'opacity-0'
                  }`}>
                    <Play className="w-12 h-12 text-yellow-400" />
                  </div>
                  
                  {/* Duration Badge */}
                  <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1">
                    <span className="pixel-font-mono text-xs text-white">
                      {video.duration}
                    </span>
                  </div>
                </div>

                {/* Video Info */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="pixel-font text-sm text-white">
                      {video.title}
                    </h4>
                    <span className="pixel-font-mono text-xs text-yellow-400 border border-yellow-400 px-2 py-1">
                      {video.type}
                    </span>
                  </div>
                  
                  <p className="pixel-font-mono text-xs text-gray-300 leading-relaxed">
                    {video.description}
                  </p>
                  
                  {/* Platform Tags */}
                  <div className="flex flex-wrap gap-2">
                    {video.platforms.map((platform, pIndex) => (
                      <span
                        key={pIndex}
                        className="pixel-font-mono text-xs text-orange-400 bg-orange-400/20 px-2 py-1"
                      >
                        {platform}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Hover Effect */}
                <div className={`absolute inset-0 bg-gradient-to-r from-yellow-400/10 to-orange-400/10 
                                opacity-0 transition-opacity duration-300 ${
                                  activeVideo === index ? 'opacity-100' : ''
                                }`} />
              </div>
            ))}
          </div>

          {/* Demo Notice */}
          <div className="text-center mt-8">
            <span className="pixel-font-mono text-xs text-gray-400">
              * Projetos demonstrativos - Vídeos reais disponíveis sob demanda
            </span>
          </div>
        </div>

        {/* Video Creation Process */}
        <div className="pixel-card p-8">
          <h3 className="pixel-font text-lg text-yellow-400 neon-glow mb-6 text-center">
            PROCESSO DE CRIAÇÃO
          </h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 border border-yellow-400/30">
              <Scissors className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <h4 className="pixel-font text-sm text-white mb-2">CORTE</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Ritmo dinâmico para prender atenção
              </p>
            </div>
            
            <div className="text-center p-4 border border-yellow-400/30">
              <Volume2 className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <h4 className="pixel-font text-sm text-white mb-2">ÁUDIO</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Mixagem clara e trilhas envolventes
              </p>
            </div>
            
            <div className="text-center p-4 border border-yellow-400/30">
              <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <h4 className="pixel-font text-sm text-white mb-2">EFEITOS</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Transições e motion graphics
              </p>
            </div>
            
            <div className="text-center p-4 border border-yellow-400/30">
              <Video className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <h4 className="pixel-font text-sm text-white mb-2">EXPORT</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Otimização para cada plataforma
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Background Effects */}
      <div className="absolute top-32 right-20 w-3 h-3 bg-yellow-400 animate-bounce opacity-30"></div>
      <div className="absolute bottom-32 left-20 w-4 h-4 bg-orange-400 animate-pulse opacity-30"></div>
    </div>
  );
};

export default VideoEditing;