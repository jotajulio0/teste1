import React, { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';

interface StartScreenProps {
  onAddXP: (amount: number) => void;
  onPlaySound: (type: 'click' | 'hover' | 'success') => void;
}

const StartScreen: React.FC<StartScreenProps> = ({ onAddXP, onPlaySound }) => {
  const [titleVisible, setTitleVisible] = useState(false);
  const [subtitleVisible, setSubtitleVisible] = useState(false);
  const [buttonsVisible, setButtonsVisible] = useState(false);

  useEffect(() => {
    const timer1 = setTimeout(() => setTitleVisible(true), 500);
    const timer2 = setTimeout(() => setSubtitleVisible(true), 1500);
    const timer3 = setTimeout(() => setButtonsVisible(true), 2500);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);

  const scrollToSection = (sectionId: string) => {
    onPlaySound('click');
    onAddXP(10);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden">
      {/* Parallax Background Layers */}
      <div className="absolute inset-0 parallax-slow" 
           style={{ 
             background: `
               radial-gradient(circle at 20% 20%, rgba(0, 229, 255, 0.1) 0%, transparent 50%),
               radial-gradient(circle at 80% 80%, rgba(0, 255, 156, 0.1) 0%, transparent 50%),
               radial-gradient(circle at 40% 60%, rgba(255, 77, 222, 0.05) 0%, transparent 50%)
             `,
             transform: `translateY(${window.scrollY * 0.5}px)`
           }} />

      {/* City Silhouette */}
     

      {/* Floating Particles */}
      <div className="absolute inset-0">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="particle"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 4}s`,
              animationDuration: `${3 + Math.random() * 2}s`
            }}
          />
        ))}
      </div>

      <div className="text-center z-10 max-w-4xl mx-auto px-4">
        {/* Main Title */}
        <h1 className={`pixel-font text-3xl md:text-5xl lg:text-6xl mb-6 transition-all duration-1000 ${
          titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <span className="text-cyan-400 neon-glow">JÚLIO CÉSAR</span>
          <br />
          <span className="text-green-400 neon-glow">DE ARAÚJO CÂNDIDO</span>
        </h1>


        {/* Subtitle */}
        <div className={`mb-12 transition-all duration-1000 delay-500 ${
          subtitleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <p className="pixel-font-mono text-lg md:text-xl lg:text-2xl text-white mb-4">
            Crio Landing Pages que convertem
          </p>
          <p className="pixel-font-mono text-md md:text-lg text-gray-300">
            com criatividade visual e foco em performance
          </p>
        </div>

        {/* Action Buttons */}
        <div className={`flex flex-col sm:flex-row gap-4 justify-center transition-all duration-1000 delay-1000 ${
          buttonsVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <button
            onClick={() => scrollToSection('about')}
            onMouseEnter={() => onPlaySound('hover')}
            className="pixel-btn px-8 py-4 pixel-font text-sm hover-lift hover-glow bg-gradient-to-r from-cyan-400 to-green-400 text-black"
          >
            [ENTER] COMEÇAR
          </button>
          
        </div>

        {/* Scroll Indicator */}
        <div className="mt-16 animate-bounce">
          <ChevronDown className="w-6 h-6 text-cyan-400 mx-auto" />
        </div>
      </div>

      {/* CRT Scanlines */}
      <div className="absolute inset-0 pointer-events-none opacity-10"
           style={{
             background: `repeating-linear-gradient(
               0deg,
               transparent,
               transparent 2px,
               rgba(0, 229, 255, 0.03) 2px,
               rgba(0, 229, 255, 0.03) 4px
             )`
           }} />
    </div>
  );
};

export default StartScreen;