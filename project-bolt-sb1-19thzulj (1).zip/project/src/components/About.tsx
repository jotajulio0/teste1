import React, { useState } from 'react';
import { Mail, Phone, Globe, Target, Video, TrendingUp, BarChart3, FileText, Zap } from 'lucide-react';

interface AboutProps {
  onAddXP: (amount: number) => void;
  onPlaySound: (type: 'click' | 'hover' | 'success') => void;
}

const About: React.FC<AboutProps> = ({ onAddXP, onPlaySound }) => {
  const [hoveredBadge, setHoveredBadge] = useState<string | null>(null);

  const badges = [
    {
      id: 'lp-ux',
      icon: Target,
      title: 'LP/UX',
      description: 'Landing Pages otimizadas para conversão'
    },
    {
      id: 'social-media',
      icon: TrendingUp,
      title: 'Social Media',
      description: 'Conteúdo estratégico para redes sociais'
    },
    {
      id: 'video-editing',
      icon: Video,
      title: 'Edição de Vídeo',
      description: 'CapCut, Premiere, After Effects'
    },
    {
      id: 'traffic',
      icon: Zap,
      title: 'Tráfego Pago',
      description: 'Campanhas básicas otimizadas'
    },
    {
      id: 'analytics',
      icon: BarChart3,
      title: 'Excel/Relatórios',
      description: 'Análise de métricas e performance'
    },
    {
      id: 'english',
      icon: Globe,
      title: 'Inglês Avançado',
      description: 'Comunicação fluente internacional'
    }
  ];

  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: 'jotadoccontact@gmail.com',
      link: 'mailto:jotadoccontact@gmail.com'
    },
    {
      icon: Phone,
      label: 'WhatsApp',
      value: '(99) 98530-6585',
      link: 'https://wa.me/5599985306585'
    }
  ];

  const handleBadgeHover = (badgeId: string) => {
    setHoveredBadge(badgeId);
    onPlaySound('hover');
  };

  const handleBadgeClick = (badgeId: string) => {
    onPlaySound('click');
    onAddXP(5);
  };

  return (
    <div className="min-h-screen py-20 px-4 relative">
      {/* Section Header */}
      <div className="max-w-6xl mx-auto text-center mb-16">
        <h2 className="pixel-font text-3xl md:text-4xl text-cyan-400 neon-glow mb-4">
          LEVEL 1: QUEM JOGA
        </h2>
        <div className="w-32 h-1 bg-gradient-to-r from-cyan-400 to-green-400 mx-auto"></div>
      </div>

      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Character & Description */}
          <div className="space-y-8">
            <div className="flex items-start space-x-6">
              <div className="character idle w-20 h-20 bg-gradient-to-br from-cyan-400 to-green-400 rounded-lg flex-shrink-0"
                   style={{
                     background: 'url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjQiIGhlaWdodD0iNjQiIHZpZXdCb3g9IjAgMCA2NCA2NCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjY0IiBoZWlnaHQ9IjY0IiBmaWxsPSIjMDBFNUZGIi8+CjxyZWN0IHg9IjE2IiB5PSIxNiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiBmaWxsPSIjMDBGRjlDIi8+CjxyZWN0IHg9IjI0IiB5PSIyNCIgd2lkdGg9IjE2IiBoZWlnaHQ9IjE2IiBmaWxsPSIjRkY0RERFIi8+Cjwvc3ZnPgo=")',
                     backgroundSize: 'cover'
                   }} />
              
              <div className="flex-1">
                <p className="pixel-font-mono text-lg text-white leading-relaxed mb-6">
                  Sou Júlio César, em início de carreira em marketing digital, com foco em criar 
                  <span className="text-cyan-400"> Landing Pages enxutas, rápidas e orientadas à conversão</span>.
                </p>
                
                <p className="pixel-font-mono text-lg text-gray-300 leading-relaxed mb-6">
                  Tenho experiência prática em <span className="text-green-400">social media</span> e 
                  <span className="text-green-400"> edição/animação de vídeos</span> (CapCut, Premiere, After Effects), 
                  e aplico análise de métricas para otimizar resultados.
                </p>
                
                <p className="pixel-font-mono text-lg text-gray-300 leading-relaxed">
                  Busco projetos para evoluir entregando 
                  <span className="text-yellow-400"> valor real em LPs, conteúdo e vídeo</span>.
                </p>
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <h3 className="pixel-font text-lg text-cyan-400 mb-4">CONTATO DIRETO</h3>
              <div className="space-y-3">
                {contactInfo.map((contact, index) => (
                  <a
                    key={index}
                    href={contact.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    onMouseEnter={() => onPlaySound('hover')}
                    onClick={() => onAddXP(5)}
                    className="flex items-center space-x-3 text-white hover:text-cyan-400 transition-colors duration-200 hover-lift"
                  >
                    <contact.icon className="w-5 h-5" />
                    <span className="pixel-font-mono">{contact.value}</span>
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Skills Badges */}
          <div className="space-y-8">
            <h3 className="pixel-font text-xl text-green-400 neon-glow text-center mb-8">
              POWER-UPS DISPONÍVEIS
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              {badges.map((badge) => (
                <div
                  key={badge.id}
                  onMouseEnter={() => handleBadgeHover(badge.id)}
                  onMouseLeave={() => setHoveredBadge(null)}
                  onClick={() => handleBadgeClick(badge.id)}
                  className="pixel-card p-4 cursor-pointer relative group"
                >
                  <div className="flex flex-col items-center text-center space-y-2">
                    <badge.icon className={`w-8 h-8 transition-colors duration-200 ${
                      hoveredBadge === badge.id ? 'text-green-400' : 'text-cyan-400'
                    }`} />
                    
                    <h4 className="pixel-font text-xs text-white">
                      {badge.title}
                    </h4>
                    
                    {/* Tooltip */}
                    <div className={`tooltip ${hoveredBadge === badge.id ? 'show' : ''}`}
                         style={{
                           bottom: '100%',
                           left: '50%',
                           transform: 'translateX(-50%)',
                           marginBottom: '8px'
                         }}>
                      {badge.description}
                    </div>
                  </div>

                  {/* Hover Effect */}
                  <div className={`absolute inset-0 bg-gradient-to-r from-cyan-400/10 to-green-400/10 
                                  opacity-0 transition-opacity duration-200 ${
                                    hoveredBadge === badge.id ? 'opacity-100' : ''
                                  }`} />
                </div>
              ))}
            </div>

            {/* XP Progress */}
            <div className="bg-black/50 p-4 border border-cyan-400">
              <div className="flex items-center justify-between mb-2">
                <span className="pixel-font-mono text-cyan-400 text-sm">PRÓXIMO NÍVEL</span>
                <span className="pixel-font-mono text-green-400 text-sm">85%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: '85%' }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Background Effects */}
      <div className="absolute top-1/4 left-10 w-2 h-2 bg-cyan-400 animate-ping"></div>
      <div className="absolute top-3/4 right-20 w-2 h-2 bg-green-400 animate-ping" style={{ animationDelay: '1s' }}></div>
      <div className="absolute top-1/2 right-10 w-2 h-2 bg-yellow-400 animate-ping" style={{ animationDelay: '2s' }}></div>
    </div>
  );
};

export default About;