import React from 'react';
import { Volume2, VolumeX, MapPin, Star, Zap } from 'lucide-react';

interface HUDProps {
  currentSection: string;
  xp: number;
  isMuted: boolean;
  onToggleMute: () => void;
}

const HUD: React.FC<HUDProps> = ({ currentSection, xp, isMuted, onToggleMute }) => {
  const sections = [
    { id: 'start', name: 'START', icon: '🏠' },
    { id: 'about', name: 'ABOUT', icon: '👤' },
    { id: 'landing-pages', name: 'LP', icon: '🎯' },
    { id: 'social-media', name: 'SOCIAL', icon: '📱' },
    { id: 'video-editing', name: 'VIDEO', icon: '🎬' },
    { id: 'projects', name: 'ARCADE', icon: '🎮' },
    { id: 'contact', name: 'BOSS', icon: '💬' }
  ];

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="hud">
      <div className="flex items-center justify-between px-4 py-2">
        {/* Player Info */}
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="character idle w-8 h-8 bg-cyan-400" 
                 style={{
                   background: 'url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiBmaWxsPSIjMDBFNUZGIi8+CjxyZWN0IHg9IjgiIHk9IjgiIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiIgZmlsbD0iIzAwRkY5QyIvPgo8L3N2Zz4K")',
                   backgroundSize: 'cover'
                 }} />
            <div className="text-cyan-400">
              <div className="pixel-font text-xs">JÚLIO CÉSAR</div>
              <div className="pixel-font-mono text-xs text-green-400">LP CREATOR</div>
            </div>
          </div>

          {/* XP Counter */}
          <div className="flex items-center space-x-2">
            <Star className="w-4 h-4 text-yellow-400" />
            <span className="pixel-font-mono text-yellow-400">{xp} XP</span>
          </div>
        </div>

        {/* Mini-map Navigation */}
        <div className="flex items-center space-x-1">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => scrollToSection(section.id)}
              className={`px-2 py-1 text-xs pixel-font-mono transition-all duration-200 hover:bg-cyan-400 hover:text-black ${
                currentSection === section.id 
                  ? 'bg-cyan-400 text-black' 
                  : 'text-cyan-400 border border-cyan-400'
              }`}
              title={section.name}
            >
              {section.icon}
            </button>
          ))}
        </div>

        {/* Controls */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onToggleMute}
            className="p-2 text-cyan-400 hover:text-white transition-colors"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default HUD;