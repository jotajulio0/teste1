import React, { useState } from 'react';
import { Gamepad2, ExternalLink, Eye, Target, TrendingUp, Zap, X } from 'lucide-react';

interface ProjectsProps {
  onAddXP: (amount: number) => void;
  onPlaySound: (type: 'click' | 'hover' | 'success') => void;
}

const Projects: React.FC<ProjectsProps> = ({ onAddXP, onPlaySound }) => {
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  const arcadeMachines = [
    {
      title: 'LP Curso de Marketing',
      objective: 'Captar leads qualificados para curso online',
      category: 'Educação',
      solution: [
        'Wireframe focado em benefícios práticos',
        'Hero section com promessa clara de ROI',
        'Formulário simplificado (apenas email)',
        'Prova social com depoimentos reais'
      ],
      expectedResult: 'Taxa de conversão projetada: 15-20%',
      tools: ['Figma', 'HTML/CSS', 'JavaScript'],
      status: 'Concluído',
      thumbnail: '🎓'
    },
    {
      title: 'LP E-commerce Fashion',
      objective: 'Aumentar vendas de coleção limitada',
      category: 'E-commerce',
      solution: [
        'Design mobile-first para público jovem',
        'Urgência com contador regressivo',
        'Galeria de produtos com zoom',
        'Checkout em uma página'
      ],
      expectedResult: 'Aumento de 30% nas conversões mobile',
      tools: ['Shopify', 'Liquid', 'CSS Grid'],
      status: 'Em desenvolvimento',
      thumbnail: '👗'
    },
    {
      title: 'LP SaaS B2B',
      objective: 'Gerar demos para ferramenta de gestão',
      category: 'Software',
      solution: [
        'Foco em problemas específicos do B2B',
        'Demo interativa da ferramenta',
        'Calculadora de ROI personalizada',
        'Formulário progressivo'
      ],
      expectedResult: 'Qualidade de leads 40% maior',
      tools: ['React', 'TypeScript', 'Tailwind'],
      status: 'Planejamento',
      thumbnail: '💼'
    },
    {
      title: 'LP Infoproduto',
      objective: 'Vender ebook sobre produtividade',
      category: 'Digital',
      solution: [
        'Storytelling sobre produtividade',
        'Preview gratuito do conteúdo',
        'Oferta limitada por tempo',
        'Garantia de 30 dias'
      ],
      expectedResult: 'Conversão projetada: 8-12%',
      tools: ['WordPress', 'Elementor', 'WooCommerce'],
      status: 'Teste A/B',
      thumbnail: '📚'
    },
    {
      title: 'LP Lead Magnet',
      objective: 'Capturar emails para newsletter',
      category: 'Conteúdo',
      solution: [
        'Oferta irresistível (checklist gratuito)',
        'Design minimalista e focado',
        'Integração com email marketing',
        'Thank you page otimizada'
      ],
      expectedResult: 'Lista de 1000+ leads qualificados',
      tools: ['Mailchimp', 'HTML5', 'Analytics'],
      status: 'Otimizando',
      thumbnail: '🧲'
    },
    {
      title: 'LP Evento Online',
      objective: 'Inscrições para webinar ao vivo',
      category: 'Eventos',
      solution: [
        'Agenda clara com palestrantes',
        'Benefícios específicos por participar',
        'Integração com Zoom/Teams',
        'Lembretes automáticos por email'
      ],
      expectedResult: '500+ inscrições confirmadas',
      tools: ['Zoom API', 'Node.js', 'MongoDB'],
      status: 'Concluído',
      thumbnail: '🎤'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Concluído': return 'text-green-400 border-green-400';
      case 'Em desenvolvimento': return 'text-yellow-400 border-yellow-400';
      case 'Teste A/B': return 'text-cyan-400 border-cyan-400';
      case 'Otimizando': return 'text-purple-400 border-purple-400';
      case 'Planejamento': return 'text-orange-400 border-orange-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  const openProject = (index: number) => {
    setSelectedProject(index);
    onPlaySound('click');
    onAddXP(15);
  };

  const closeProject = () => {
    setSelectedProject(null);
    onPlaySound('click');
  };

  return (
    <div className="min-h-screen py-20 px-4 relative">
      {/* Section Header */}
      <div className="max-w-6xl mx-auto text-center mb-16">
        <h2 className="pixel-font text-3xl md:text-4xl text-purple-400 neon-glow mb-4">
          ARCADE: PROJETOS & EXPERIMENTOS
        </h2>
        <p className="pixel-font-mono text-lg text-white mb-2">
          Estou construindo portfólio com projetos próprios e estudos guiados.
        </p>
        <p className="pixel-font-mono text-lg text-gray-300">
          Topo freelas e testes técnicos.
        </p>
        <div className="w-48 h-1 bg-gradient-to-r from-purple-400 to-pink-400 mx-auto mt-4"></div>
      </div>

      <div className="max-w-6xl mx-auto">
        {/* Arcade Machines Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {arcadeMachines.map((machine, index) => (
            <div
              key={index}
              onClick={() => openProject(index)}
              onMouseEnter={() => onPlaySound('hover')}
              className="pixel-card p-6 cursor-pointer hover-lift relative group overflow-hidden"
            >
              {/* Machine Screen */}
              <div className="aspect-video bg-black border-2 border-purple-400/50 mb-4 flex items-center justify-center relative">
                <div className="text-4xl">{machine.thumbnail}</div>
                
                {/* CRT Effect */}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-400/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                
                {/* Status Badge */}
                <div className={`absolute top-2 right-2 px-2 py-1 border text-xs pixel-font-mono ${getStatusColor(machine.status)}`}>
                  {machine.status}
                </div>
              </div>

              {/* Machine Info */}
              <div className="space-y-3">
                <h3 className="pixel-font text-sm text-white">{machine.title}</h3>
                <p className="pixel-font-mono text-xs text-gray-300 line-clamp-2">
                  {machine.objective}
                </p>
                
                <div className="flex items-center justify-between">
                  <span className="pixel-font-mono text-xs text-purple-400 border border-purple-400 px-2 py-1">
                    {machine.category}
                  </span>
                  
                  <div className="flex items-center space-x-1">
                    <Gamepad2 className="w-4 h-4 text-cyan-400" />
                    <span className="pixel-font-mono text-xs text-cyan-400">PLAY</span>
                  </div>
                </div>
              </div>

              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400/10 to-pink-400/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </div>
          ))}
        </div>

        {/* Value Proposition */}
        <div className="pixel-card p-8 text-center">
          <h3 className="pixel-font text-xl text-green-400 neon-glow mb-6">
            PRONTO PARA PROJETOS REAIS
          </h3>
          
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="p-4">
              <Target className="w-12 h-12 text-green-400 mx-auto mb-3" />
              <h4 className="pixel-font text-sm text-white mb-2">FOCO EM RESULTADO</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Cada projeto visa métricas claras de conversão
              </p>
            </div>
            
            <div className="p-4">
              <TrendingUp className="w-12 h-12 text-cyan-400 mx-auto mb-3" />
              <h4 className="pixel-font text-sm text-white mb-2">EVOLUÇÃO CONSTANTE</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Aprendizado ativo com cada novo desafio
              </p>
            </div>
            
            <div className="p-4">
              <Zap className="w-12 h-12 text-yellow-400 mx-auto mb-3" />
              <h4 className="pixel-font text-sm text-white mb-2">ENTREGA ÁGIL</h4>
              <p className="pixel-font-mono text-xs text-gray-300">
                Protótipos rápidos para validar ideias
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              onPlaySound('success');
              onAddXP(20);
              document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="pixel-btn px-8 py-4 pixel-font text-sm hover-lift hover-glow bg-gradient-to-r from-green-400 to-cyan-400 text-black"
          >
            VAMOS CRIAR ALGO JUNTOS?
          </button>
        </div>
      </div>

      {/* Project Modal */}
      {selectedProject !== null && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="pixel-card max-w-4xl w-full max-h-[90vh] overflow-y-auto p-8 relative">
            {/* Close Button */}
            <button
              onClick={closeProject}
              className="absolute top-4 right-4 text-white hover:text-cyan-400 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="text-6xl mb-4">{arcadeMachines[selectedProject].thumbnail}</div>
                <h2 className="pixel-font text-2xl text-cyan-400 neon-glow">
                  {arcadeMachines[selectedProject].title}
                </h2>
                <span className={`pixel-font-mono text-sm px-3 py-1 border mt-2 inline-block ${
                  getStatusColor(arcadeMachines[selectedProject].status)
                }`}>
                  {arcadeMachines[selectedProject].status}
                </span>
              </div>

              <div className="grid lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <h3 className="pixel-font text-green-400 mb-3">OBJETIVO</h3>
                    <p className="pixel-font-mono text-white">
                      {arcadeMachines[selectedProject].objective}
                    </p>
                  </div>

                  <div>
                    <h3 className="pixel-font text-green-400 mb-3">SOLUÇÃO</h3>
                    <ul className="space-y-2">
                      {arcadeMachines[selectedProject].solution.map((item, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <span className="text-cyan-400 mt-1">•</span>
                          <span className="pixel-font-mono text-sm text-gray-300">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h3 className="pixel-font text-green-400 mb-3">RESULTADO ESPERADO</h3>
                    <p className="pixel-font-mono text-yellow-400">
                      {arcadeMachines[selectedProject].expectedResult}
                    </p>
                  </div>

                  <div>
                    <h3 className="pixel-font text-green-400 mb-3">FERRAMENTAS</h3>
                    <div className="flex flex-wrap gap-2">
                      {arcadeMachines[selectedProject].tools.map((tool, index) => (
                        <span
                          key={index}
                          className="pixel-font-mono text-xs text-cyan-400 bg-cyan-400/20 px-2 py-1 border border-cyan-400/50"
                        >
                          {tool}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={() => {
                        onPlaySound('success');
                        onAddXP(10);
                        document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                        closeProject();
                      }}
                      className="pixel-btn w-full py-3 pixel-font text-sm hover-lift bg-gradient-to-r from-purple-400 to-pink-400 text-black"
                    >
                      QUERO ALGO ASSIM
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Background Decoration */}
      <div className="absolute top-40 left-20 w-6 h-6 border border-purple-400 animate-pulse opacity-20"></div>
      <div className="absolute bottom-40 right-20 w-4 h-4 bg-pink-400 rotate-45 animate-bounce opacity-20"></div>
    </div>
  );
};

export default Projects;