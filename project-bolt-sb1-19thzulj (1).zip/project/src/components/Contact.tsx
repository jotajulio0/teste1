import React, { useState } from 'react';
import { Send, MessageSquare, Mail, Phone, CheckCircle, Zap } from 'lucide-react';

interface ContactProps {
  onAddXP: (amount: number) => void;
  onPlaySound: (type: 'click' | 'hover' | 'success') => void;
}

const Contact: React.FC<ContactProps> = ({ onAddXP, onPlaySound }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    project: 'landing-page',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [terminalOutput, setTerminalOutput] = useState([
    '> Sistema de contato inicializado...',
    '> Aguardando missão...',
    '> Digite seus dados para continuar'
  ]);

  const projectTypes = [
    { value: 'landing-page', label: 'Landing Page', icon: '🎯' },
    { value: 'social-media', label: 'Social Media', icon: '📱' },
    { value: 'video-editing', label: 'Edição de Vídeo', icon: '🎬' },
    { value: 'consultation', label: 'Consultoria', icon: '💡' }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    onPlaySound('hover');
    
    // Real-time validation feedback
    if (value.length > 0) {
      addTerminalLine(`> ${name.toUpperCase()}: Validado ✓`);
    }
  };

  const addTerminalLine = (line: string) => {
    setTerminalOutput(prev => [...prev, line].slice(-6)); // Keep last 6 lines
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    onPlaySound('click');

    // Simulate form submission
    addTerminalLine('> Enviando missão...');
    
    setTimeout(() => {
      addTerminalLine('> Conexão estabelecida...');
      
      setTimeout(() => {
        addTerminalLine('> Missão enviada com sucesso! ✓');
        addTerminalLine('> Resposta estimada: 2-4 horas');
        setIsSubmitted(true);
        setIsSubmitting(false);
        onPlaySound('success');
        onAddXP(50);
        
        // Character celebration effect
        setTimeout(() => {
          addTerminalLine('> XP +50 | Achievement: "First Contact"');
        }, 1000);
      }, 1500);
    }, 1000);
  };

  const openWhatsApp = () => {
    const message = `Olá, Júlio! Vim pelo seu portfólio pixel e gostaria de conversar sobre: ${
      projectTypes.find(p => p.value === formData.project)?.label || 'um projeto'
    }`;
    const whatsappUrl = `https://wa.me/5599985306585?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    onPlaySound('success');
    onAddXP(25);
  };

  return (
    <div className="min-h-screen py-20 px-4 relative">
      {/* Section Header */}
      <div className="max-w-6xl mx-auto text-center mb-16">
        <h2 className="pixel-font text-3xl md:text-4xl text-red-400 neon-glow mb-4">
          BOSS ROOM: CONTATO
        </h2>
        <p className="pixel-font-mono text-lg text-white mb-2">
          Pronto para a fase final?
        </p>
        <p className="pixel-font-mono text-lg text-gray-300">
          Vamos conversar sobre seu projeto
        </p>
        <div className="w-32 h-1 bg-gradient-to-r from-red-400 to-pink-400 mx-auto mt-4"></div>
      </div>

      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12">
       

          {/* Direct Contact & Info */}
          <div className="space-y-8">
            {/* Quick Contact */}
            <div className="pixel-card p-8">
              <h3 className="pixel-font text-xl text-cyan-400 neon-glow mb-6 text-center">
                CONTATO DIRETO
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-center space-x-4 p-4 border border-cyan-400/30 hover:border-cyan-400 transition-colors">
                  <Mail className="w-8 h-8 text-cyan-400" />
                  <div>
                    <p className="pixel-font text-sm text-white">Email</p>
                    <a 
                      href="mailto:jotadoccontact@gmail.com"
                      className="pixel-font-mono text-cyan-400 hover:text-white transition-colors"
                    >
                      jotadoccontact@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-4 border border-green-400/30 hover:border-green-400 transition-colors">
                  <Phone className="w-8 h-8 text-green-400" />
                  <div>
                    <p className="pixel-font text-sm text-white">WhatsApp</p>
                    <a 
                      href="https://wa.me/5599985306585"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="pixel-font-mono text-green-400 hover:text-white transition-colors"
                    >
                      (99) 98530-6585
                    </a>
                  </div>
                </div>
              </div>

              <button
                onClick={openWhatsApp}
                onMouseEnter={() => onPlaySound('hover')}
                className="w-full mt-6 py-4 pixel-btn bg-gradient-to-r from-green-400 to-cyan-400 text-black pixel-font text-sm hover-lift hover-glow"
              >
                <MessageSquare className="w-4 h-4 inline mr-2" />
                FALAR NO WHATSAPP
              </button>
            </div>


            {/* Availability */}
            <div className="pixel-card p-6">
              <h4 className="pixel-font text-lg text-purple-400 neon-glow mb-4 text-center">
                DISPONIBILIDADE
              </h4>
              
              <div className="space-y-2 pixel-font-mono text-sm">
                <div className="flex justify-between items-center">
                  <span className="text-white">Seg - Sex:</span>
                  <span className="text-green-400">8h - 18h</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white">Sábado:</span>
                  <span className="text-yellow-400">9h - 14h</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white">Domingo:</span>
                  <span className="text-red-400">Emergência</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Background Effects */}
      <div className="absolute top-20 left-10 w-4 h-4 bg-red-400 animate-pulse opacity-20"></div>
      <div className="absolute bottom-20 right-10 w-3 h-3 bg-pink-400 animate-bounce opacity-20"></div>
    </div>
  );
};
export default Contact;