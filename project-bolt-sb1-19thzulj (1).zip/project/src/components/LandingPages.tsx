import React, { useState } from 'react';
import { Target, Zap, BarChart3, Settings, Accessibility, Globe, Eye, CheckCircle, ArrowRight } from 'lucide-react';

interface LandingPagesProps {
  onAddXP: (amount: number) => void;
  onPlaySound: (type: 'click' | 'hover' | 'success') => void;
}

const LandingPages: React.FC<LandingPagesProps> = ({ onAddXP, onPlaySound }) => {
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [simulatorConfig, setSimulatorConfig] = useState({
    heroStyle: 'simple',
    ctaColor: 'blue',
    socialProof: true,
    titleSize: 'large'
  });

  const modules = [
    {
      id: 'architecture',
      icon: Target,
      title: 'Arquitetura & UX',
      description: 'Hierarquia visual, padrões de dobra, CTA visível e fricção mínima'
    },
    {
      id: 'copy',
      icon: Eye,
      title: 'Copy & Oferta',
      description: 'Valor claro em 5s, prova social e objeções mapeadas'
    },
    {
      id: 'speed',
      icon: Zap,
      title: 'Velocidade & Técnica',
      description: 'Imagens otimizadas, lazy load, Lighthouse verde'
    },
    {
      id: 'testing',
      icon: BarChart3,
      title: 'Testes & Métricas',
      description: 'UTM, eventos, heatmaps e iterações'
    },
    {
      id: 'integrations',
      icon: Settings,
      title: 'Integrações',
      description: 'Formulários, CRM, automações e pixel'
    },
    {
      id: 'accessibility',
      icon: Accessibility,
      title: 'Acessibilidade',
      description: 'Contraste, navegação via teclado e ARIA'
    }
  ];

  const processSteps = [
    'Brief & Meta',
    'Wireframe Rápido',
    'Protótipo Visual',
    'Implementação',
    'Medir e Otimizar'
  ];

  const calculateScore = () => {
    let clarity = 50;
    let ctaFocus = 50;

    if (simulatorConfig.heroStyle === 'simple') clarity += 20;
    if (simulatorConfig.ctaColor === 'blue') ctaFocus += 15;
    if (simulatorConfig.socialProof) clarity += 15;
    if (simulatorConfig.titleSize === 'large') ctaFocus += 20;

    return { clarity: Math.min(clarity, 100), ctaFocus: Math.min(ctaFocus, 100) };
  };

  const scores = calculateScore();

  const handleModuleHover = (moduleId: string) => {
    setActiveModule(moduleId);
    onPlaySound('hover');
  };

  const handleConfigChange = (key: string, value: string | boolean) => {
    setSimulatorConfig(prev => ({ ...prev, [key]: value }));
    onPlaySound('click');
    onAddXP(3);
  };

  return (
    <div className="min-h-screen py-20 px-4 relative">
      {/* Section Header */}
      <div className="max-w-6xl mx-auto text-center mb-16">
        <h2 className="pixel-font text-3xl md:text-4xl text-cyan-400 neon-glow mb-4">
          LEVEL PRINCIPAL: LANDING PAGES
        </h2>
        <p className="pixel-font-mono text-xl text-green-400 mb-2">
          Do conceito à conversão
        </p>
        <p className="pixel-font-mono text-gray-300">
          Arquitetura clara, copy objetiva, carregamento rápido e testes contínuos
        </p>
        <div className="w-48 h-1 bg-gradient-to-r from-cyan-400 to-green-400 mx-auto mt-4"></div>
      </div>

      <div className="max-w-7xl mx-auto space-y-16">
        {/* Modules Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {modules.map((module) => (
            <div
              key={module.id}
              onMouseEnter={() => handleModuleHover(module.id)}
              onMouseLeave={() => setActiveModule(null)}
              onClick={() => onAddXP(10)}
              className="pixel-card p-6 cursor-pointer relative group"
            >
              <div className="flex items-center space-x-4 mb-4">
                <div className={`p-3 rounded-lg ${
                  activeModule === module.id 
                    ? 'bg-green-400 text-black' 
                    : 'bg-cyan-400/20 text-cyan-400'
                }`}>
                  <module.icon className="w-6 h-6" />
                </div>
                
                <h3 className="pixel-font text-sm text-white">
                  {module.title}
                </h3>
              </div>
              
              <p className="pixel-font-mono text-xs text-gray-300 leading-relaxed">
                {module.description}
              </p>

              {/* Hover Indicator */}
              <div className={`absolute top-2 right-2 w-2 h-2 rounded-full ${
                activeModule === module.id ? 'bg-green-400 animate-pulse' : 'bg-transparent'
              }`} />
            </div>
          ))}
        </div>

        {/* Interactive Simulator */}
        <div className="pixel-card p-8">
          <h3 className="pixel-font text-xl text-green-400 neon-glow mb-8 text-center">
            SIMULADOR INTERATIVO DE LP
          </h3>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Controls */}
            <div className="space-y-6">
              <h4 className="pixel-font text-cyan-400 mb-4">CONFIGURAÇÕES</h4>
              
              <div className="space-y-4">
                <div>
                  <label className="pixel-font-mono text-sm text-white block mb-2">
                    Estilo do Hero:
                  </label>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleConfigChange('heroStyle', 'simple')}
                      className={`px-4 py-2 pixel-font-mono text-xs ${
                        simulatorConfig.heroStyle === 'simple'
                          ? 'bg-cyan-400 text-black'
                          : 'border border-cyan-400 text-cyan-400'
                      }`}
                    >
                      Simples
                    </button>
                    <button
                      onClick={() => handleConfigChange('heroStyle', 'complex')}
                      className={`px-4 py-2 pixel-font-mono text-xs ${
                        simulatorConfig.heroStyle === 'complex'
                          ? 'bg-cyan-400 text-black'
                          : 'border border-cyan-400 text-cyan-400'
                      }`}
                    >
                      Complexo
                    </button>
                  </div>
                </div>

                <div>
                  <label className="pixel-font-mono text-sm text-white block mb-2">
                    Cor do CTA:
                  </label>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleConfigChange('ctaColor', 'blue')}
                      className={`w-8 h-8 bg-blue-500 ${
                        simulatorConfig.ctaColor === 'blue' ? 'ring-2 ring-white' : ''
                      }`}
                    />
                    <button
                      onClick={() => handleConfigChange('ctaColor', 'green')}
                      className={`w-8 h-8 bg-green-500 ${
                        simulatorConfig.ctaColor === 'green' ? 'ring-2 ring-white' : ''
                      }`}
                    />
                    <button
                      onClick={() => handleConfigChange('ctaColor', 'red')}
                      className={`w-8 h-8 bg-red-500 ${
                        simulatorConfig.ctaColor === 'red' ? 'ring-2 ring-white' : ''
                      }`}
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="socialProof"
                    checked={simulatorConfig.socialProof}
                    onChange={(e) => handleConfigChange('socialProof', e.target.checked)}
                    className="w-4 h-4"
                  />
                  <label htmlFor="socialProof" className="pixel-font-mono text-sm text-white">
                    Prova Social
                  </label>
                </div>

                <div>
                  <label className="pixel-font-mono text-sm text-white block mb-2">
                    Tamanho do Título:
                  </label>
                  <select
                    value={simulatorConfig.titleSize}
                    onChange={(e) => handleConfigChange('titleSize', e.target.value)}
                    className="bg-black border border-cyan-400 text-cyan-400 pixel-font-mono text-sm p-2"
                  >
                    <option value="small">Pequeno</option>
                    <option value="medium">Médio</option>
                    <option value="large">Grande</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Preview */}
            <div className="space-y-4">
              <h4 className="pixel-font text-cyan-400 mb-4">PREVIEW EM TEMPO REAL</h4>
              
              <div className="bg-white text-black p-6 min-h-80 transition-all duration-500">
                <div className={`mb-6 ${
                  simulatorConfig.titleSize === 'large' ? 'text-2xl' : 
                  simulatorConfig.titleSize === 'medium' ? 'text-xl' : 'text-lg'
                }`}>
                  {simulatorConfig.heroStyle === 'simple' 
                    ? 'Título Direto e Claro' 
                    : 'Título Complexo com Múltiplas Informações Detalhadas'}
                </div>
                
                <p className="text-gray-700 mb-6">
                  Descrição da oferta com benefícios claros e diretos.
                </p>
                
                {simulatorConfig.socialProof && (
                  <div className="mb-6 p-3 bg-gray-100">
                    ⭐⭐⭐⭐⭐ "Resultados incríveis!" - Cliente Satisfeito
                  </div>
                )}
                
                <button 
                  className={`px-8 py-3 text-white font-bold ${
                    simulatorConfig.ctaColor === 'blue' ? 'bg-blue-500' :
                    simulatorConfig.ctaColor === 'green' ? 'bg-green-500' : 'bg-red-500'
                  }`}
                >
                  CALL TO ACTION
                </button>
              </div>

              {/* Performance Indicators */}
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="pixel-font-mono text-xs text-white">Clareza</span>
                    <span className="pixel-font-mono text-xs text-cyan-400">{scores.clarity}%</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width: `${scores.clarity}%` }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="pixel-font-mono text-xs text-white">Foco no CTA</span>
                    <span className="pixel-font-mono text-xs text-green-400">{scores.ctaFocus}%</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width: `${scores.ctaFocus}%` }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Process Timeline */}
        <div className="pixel-card p-8">
          <h3 className="pixel-font text-xl text-green-400 neon-glow mb-8 text-center">
            MEU PROCESSO EM 5 FASES
          </h3>
          
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0 md:space-x-4">
            {processSteps.map((step, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-cyan-400 to-green-400 rounded-full flex items-center justify-center mb-3">
                  <span className="pixel-font text-black text-lg">{index + 1}</span>
                </div>
                
                <h4 className="pixel-font text-xs text-white mb-2">{step}</h4>
                
                {index < processSteps.length - 1 && (
                  <div className="hidden md:block absolute">
                    <ArrowRight className="w-6 h-6 text-cyan-400" style={{
                      transform: `translateX(${80}px)`
                    }} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <button
            onClick={() => {
              onPlaySound('success');
              onAddXP(25);
              document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="pixel-btn px-12 py-6 pixel-font text-lg hover-lift hover-glow bg-gradient-to-r from-green-400 to-cyan-400 text-black"
          >
            PRECISA DE UMA LP QUE CONVERTE?
            <br />
            <span className="text-sm">FALE COMIGO AGORA</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default LandingPages;